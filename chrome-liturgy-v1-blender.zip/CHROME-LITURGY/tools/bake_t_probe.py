import bpy,numpy as np
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene;s.frame_set(73)
for o in s.objects:
 if o.name=='T' or o.name.startswith(('Ring','Disc')):o.hide_render=True
 if o.type=='MESH' and o.data.materials and o.data.materials[0].name.endswith('diffusion'):o.visible_camera=True
cam=s.camera;cam.location=(0,0,6.5);cam.rotation_euler=(np.pi/2,0,0);cam.data.type='PANO';cam.data.panorama_type='EQUIRECTANGULAR';cam.data.dof.use_dof=False
s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=8;s.cycles.samples=64;s.render.resolution_x=1024;s.render.resolution_y=512;s.render.resolution_percentage=100;s.render.image_settings.file_format='OPEN_EXR';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='16';s.render.filepath=str(B/'renders/t-studio-linear.exr')
bpy.ops.render.render(write_still=True);im=bpy.data.images.load(str(B/'renders/t-studio-linear.exr'));pix=np.array(im.pixels[:],dtype='<f2').reshape(512,1024,4);(B/'repository/chrome-liturgy-v1-t-studio.f16').write_bytes(np.roll(pix,-256,axis=1).tobytes());print('T_PROBE_READY',flush=True)
