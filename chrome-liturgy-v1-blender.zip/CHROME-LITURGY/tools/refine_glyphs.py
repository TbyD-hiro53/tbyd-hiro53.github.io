import bpy,json
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
g=json.loads((B/'reference/glyphs.json').read_text())
for k in range(4):
 o=bpy.data.objects[f'Ring{k}'];material=o.data.materials[0];old=o.data;data=g[f'Glyph{k}'];me=bpy.data.meshes.new(f'Lettering{k}');me.from_pydata(data['p'],[],data['faces']);me.update();me.materials.append(material);o.data=me
 for p in me.polygons:p.use_smooth=True
 bpy.context.view_layer.objects.active=o;bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
 if old.users==0:bpy.data.meshes.remove(old)
 o['source']='v25 alpha glyphs; image-only vertical padding trimmed to fill the original ring shell; radial thickness 0.038'
s.frame_set(73);s.render.resolution_x=750;s.render.resolution_y=900;s.render.resolution_percentage=100;s.cycles.samples=48;s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=8
bpy.ops.wm.save_as_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'))
s.render.filepath=str(B/'renders/glyph-refined.png');bpy.ops.render.render(write_still=True)
