import bpy
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene;s.frame_set(73)
s.cycles.device='CPU';s.cycles.samples=64;s.render.threads_mode='FIXED';s.render.threads=8
old=bpy.data.objects['GalleryFloor'];old.hide_render=True
bpy.ops.mesh.primitive_plane_add(size=16,location=(0,0,-2.7));o=bpy.context.object;o.name='Floor diffuse radiance bake';m=old.data.materials[0].copy();o.data.materials.append(m)
im=bpy.data.images.new('Floor diffuse radiance',width=1024,height=1024,alpha=False);im.colorspace_settings.name='sRGB';n=m.node_tree.nodes.new('ShaderNodeTexImage');n.image=im;m.node_tree.nodes.active=n
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
s.render.bake.use_pass_direct=True;s.render.bake.use_pass_indirect=True;s.render.bake.use_pass_color=True;s.render.bake.margin=4
bpy.ops.object.bake(type='DIFFUSE');im.filepath_raw=str(B/'repository/chrome-liturgy-v1-floor-light.png');im.file_format='PNG';im.save();print('FLOOR_LIGHT_READY',flush=True)
