import bpy,math,json,sys,array
from pathlib import Path
from mathutils import Vector
import numpy as np
B=Path(__file__).resolve().parents[1]; R=B/'repository'; PREFIX='chrome-liturgy-v1'
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.name='CHROME LITURGY • physical master'
s.render.engine='CYCLES';s.cycles.device='GPU';s.cycles.samples=96;s.cycles.use_denoising=True
prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='METAL';prefs.refresh_devices()
for d in prefs.devices:d.use=d.type=='METAL'
print('DEVICES',[(d.name,d.type,d.use) for d in prefs.devices],flush=True)
s.cycles.max_bounces=12;s.cycles.transmission_bounces=8;s.cycles.glossy_bounces=8
s.render.resolution_x=1000;s.render.resolution_y=1200;s.render.resolution_percentage=100
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.fps=60
s.frame_start=1;s.frame_end=865;s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast'
s.world=bpy.data.worlds.new('Dark neutral studio');s.world.use_nodes=True
s.world.node_tree.nodes.get('Background').inputs[0].default_value=(.08,.095,.12,1)
s.world.node_tree.nodes.get('Background').inputs[1].default_value=.24
def mat(name,color,metal,rough):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF')
 p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m,p
def noise(m,scale,detail=2):
 n=m.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=scale;n.inputs['Detail'].default_value=detail;return n
def micro(m,p,scale,dist,low,high):
 nt=m.node_tree;n=noise(m,scale);b=nt.nodes.new('ShaderNodeBump');b.inputs['Distance'].default_value=dist;b.inputs['Strength'].default_value=.22
 nt.links.new(n.outputs['Fac'],b.inputs['Height']);nt.links.new(b.outputs['Normal'],p.inputs['Normal'])
 r=nt.nodes.new('ShaderNodeMapRange');r.inputs['To Min'].default_value=low;r.inputs['To Max'].default_value=high;nt.links.new(noise(m,4).outputs['Fac'],r.inputs[0]);nt.links.new(r.outputs[0],p.inputs['Roughness'])
 return b
tmat,p=mat('T • rose / carmine PVD on polished titanium',(.52,.035,.18),.92,.22)
p.inputs['Coat Weight'].default_value=.48;p.inputs['Coat Roughness'].default_value=.16
if 'Thin Film Thickness' in p.inputs:p.inputs['Thin Film Thickness'].default_value=280;p.inputs['Thin Film IOR'].default_value=1.38
nt=tmat.node_tree;tx=nt.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(B/'reference/gradHo.png'));nt.links.new(tx.outputs['Color'],p.inputs['Base Color'])
micro(tmat,p,700,.00013,.19,.27)
chrome,p=mat('Wafer • circular lapped chromium',(.64,.70,.74),1,.21)
p.inputs['Anisotropic'].default_value=.42;p.inputs['Coat Weight'].default_value=.24;p.inputs['Coat Roughness'].default_value=.13
nt=chrome.node_tree;tc=nt.nodes.new('ShaderNodeTexCoord');sep=nt.nodes.new('ShaderNodeSeparateXYZ');nt.links.new(tc.outputs['Object'],sep.inputs[0])
comb=nt.nodes.new('ShaderNodeCombineXYZ');nt.links.new(sep.outputs['X'],comb.inputs['X']);nt.links.new(sep.outputs['Y'],comb.inputs['Y'])
length=nt.nodes.new('ShaderNodeVectorMath');length.operation='LENGTH';nt.links.new(comb.outputs[0],length.inputs[0])
mult=nt.nodes.new('ShaderNodeMath');mult.operation='MULTIPLY';mult.inputs[1].default_value=4200;nt.links.new(length.outputs['Value'],mult.inputs[0])
sine=nt.nodes.new('ShaderNodeMath');sine.operation='SINE';nt.links.new(mult.outputs[0],sine.inputs[0])
b=nt.nodes.new('ShaderNodeBump');b.inputs['Distance'].default_value=.000035;b.inputs['Strength'].default_value=.32;nt.links.new(sine.outputs[0],b.inputs['Height']);nt.links.new(b.outputs[0],p.inputs['Normal'])
rn=nt.nodes.new('ShaderNodeMapRange');rn.inputs['To Min'].default_value=.17;rn.inputs['To Max'].default_value=.25;nt.links.new(noise(chrome,110).outputs['Fac'],rn.inputs[0]);nt.links.new(rn.outputs[0],p.inputs['Roughness'])
glyphm=[]
for k in range(4):
 c=(.012,.62,.53) if k<3 else (.82,.86,.8)
 m,p=mat(('Turquoise' if k<3 else 'Ivory')+' • opal glass lightguide',c,.12,.23)
 p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=1.65 if k<3 else .9
 p.inputs['Coat Weight'].default_value=.5;p.inputs['Coat Roughness'].default_value=.12
 glyphm.append(m)
floor,p=mat('Floor • honed black gabbro',(.024,.029,.031),.1,.32);micro(floor,p,190,.0007,.24,.36)
nt=floor.node_tree;ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.28;ramp.color_ramp.elements[0].color=(.012,.015,.018,1);ramp.color_ramp.elements[1].position=.72;ramp.color_ramp.elements[1].color=(.035,.041,.044,1);nt.links.new(noise(floor,380).outputs['Fac'],ramp.inputs[0]);nt.links.new(ramp.outputs[0],p.inputs['Base Color'])
wall,p=mat('Walls • charcoal lime plaster',(.055,.063,.07),0,.76);micro(wall,p,80,.001,.69,.82)
def mesh(name,verts,faces,material,uv=None,normals=None):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);s.collection.objects.link(o);o.data.materials.append(material)
 for f in me.polygons:f.use_smooth=True
 if uv:
  layer=me.uv_layers.new(name='Original UV')
  for poly in me.polygons:
   for li in poly.loop_indices:layer.data[li].uv=uv[me.loops[li].vertex_index]
 if normals:me.normals_split_custom_set_from_vertices(normals)
 return o
def convert(v):return (v[0],-v[2],v[1])
G=json.loads((B/'reference/geometry.json').read_text());glyphs=json.loads((B/'reference/glyphs.json').read_text())
model=[]
def original(key,name,material):
 g=G[key];o=mesh(name,[convert(p) for p in g['p']],g['tri'],material,g['uv'],[convert(p) for p in g['n']]);model.append(o);return o
t=original('T','T',tmat);bev=t.modifiers.new('Machined edge radii · 12 mm','BEVEL');bev.width=.012;bev.segments=4
t['source']='Exact decoded v25 geometry; physical edge treatment only'
ys=[6.5,5.550000190734863,4.599999904632568,3.5838000774383545];speeds=[-.42,.6,-.5,.36]
rings=[]
for k in range(4):
 g=glyphs[f'Glyph{k}'];o=mesh(f'Ring{k}',g['p'],g['faces'],glyphm[k]);o.location.z=ys[k]
 # Consistent outward normals on the watertight glyph shells.
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
 o['source']='Original v25 alpha silhouette, extruded radially 38 mm';rings.append(o);model.append(o)
disc=original('disc','DiscTop',chrome);bev=disc.modifiers.new('Lapped rim · 3 mm','BEVEL');bev.width=.003;bev.segments=3
disc.location.z=3;disc.scale=(2.05,)*3
discs=[]
for i in range(6):
 o=disc.copy();o.name=f'Disc{i}';o.data=disc.data;s.collection.objects.link(o);model.append(o);discs.append(o)
Y=[3,2.45,1.8,1,0,-1.05,-2.15];S=[2.05,1.6,1.22,.88,.56,.3,.02]
def pose(u):
 if u<14.28:
  i=min(5,int(u/2.38));f=(u-i*2.38)/2.38;return Y[i]+(Y[i+1]-Y[i])*f,S[i]+(S[i+1]-S[i])*f
 if u<14.32:return Y[6],S[6]*(1-(u-14.28)/.04)
 if u<14.36:return (Y[6] if u<14.34 else Y[0]),0
 return Y[0],S[0]*(u-14.36)/.04
for frame in range(1,866):
 time=(frame-1)/60
 t.location.z=.18*math.sin(2*math.pi*time/8);t.keyframe_insert('location',frame=frame)
 for k,o in enumerate(rings):o.rotation_euler.z=speeds[k]*time;o.keyframe_insert('rotation_euler',frame=frame)
 for i,o in enumerate(discs):
  z,sc=pose((time-i*2.4)%14.4);o.location.z=z;o.scale=(sc,)*3;o.keyframe_insert('location',frame=frame);o.keyframe_insert('scale',frame=frame)
  o.hide_render=sc<.0001 or (abs(z-3)<1e-7 and abs(sc-2.05)<1e-7);o.keyframe_insert('hide_render',frame=frame)
for action in bpy.data.actions:
 for layer in action.layers:
  for strip in layer.strips:
   for slot in action.slots:
    for fc in strip.channelbag(slot).fcurves:
     for key in fc.keyframe_points:key.interpolation='LINEAR'
def box(name,loc,scale,material,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material)
 if bevel:b=o.modifiers.new('Soft architectural edges','BEVEL');b.width=bevel;b.segments=3
 return o
architecture=[]
architecture.append(box('GalleryFloor',(0,0,-2.8),(80,80,.2),floor,.05))
architecture.append(box('GalleryWall',(0,12,12),(80,.3,30),wall,.08))
# Broad reflection cards: real luminous surfaces, physically reflected by the metal.
cards=[]
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def panel(name,loc,target,width,height,color,power):
 m=bpy.data.materials.new(name+' diffusion');m.use_nodes=True;nt=m.node_tree;nt.nodes.clear();e=nt.nodes.new('ShaderNodeEmission');e.inputs[0].default_value=(*color,1);e.inputs[1].default_value=power;out=nt.nodes.new('ShaderNodeOutputMaterial');nt.links.new(e.outputs[0],out.inputs[0])
 bpy.ops.mesh.primitive_plane_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.scale=(width,height,1);aim(o,target);o.data.materials.append(m);cards.append(o);return o
panel('Key • silk 4 × 11 m',(-7,-4,9),(0,0,3),4,11,(1,.9,.8),13)
panel('Rim • cold vertical strip',(5,3,7),(0,0,4),1.5,12,(.68,.82,1),20)
panel('Overhead • long diffusion',(0,1,13),(0,0,3),9,3,(1,.97,.92),11)
panel('Fill • frontal silk',(2,-10,5),(0,0,4),5,7,(.83,.9,1),4)
panel('Rear • luminous reveal',(-4,7,4),(0,0,4),.25,11,(.72,.88,1),8)
# Separate small accent yields the tight, photographic glints that large cards cannot.
ld=bpy.data.lights.new('Edge glint','AREA');lo=bpy.data.objects.new('Edge glint',ld);s.collection.objects.link(lo);lo.location=(3,-4,10);ld.energy=850;ld.shape='DISK';ld.size=1.2;aim(lo,(0,0,5))
bpy.ops.object.camera_add(location=(11,-19,8));cam=bpy.context.object;cam.name='Hero • 70 mm';cam.data.lens=60;aim(cam,(0,0,3.1));s.camera=cam
cam.data.dof.use_dof=True;cam.data.dof.focus_distance=(cam.location-Vector((0,0,4))).length;cam.data.dof.aperture_fstop=11
s.frame_set(73)
s['source_revision']='b4f574c';s['source_work']='Cyberwafer v25';s['title_status']='Working title, pending author selection'
s['animation']='v25: 0.78 s tap pulse; 2.4 s slots; 14.4 s conveyor; T 0.18 / 8 s; rings -0.42,+0.60,-0.50,+0.36 rad/s'
s['materials']='Physically shaded metallic T, machined chrome, extruded opal glyphs; procedural microscopic finish; no emissive T'
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'))
s.render.filepath=str(B/'renders/hero-study.png');bpy.ops.render.render(write_still=True)
print('HERO_READY',flush=True)
