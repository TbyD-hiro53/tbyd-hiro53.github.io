import bpy,math
from mathutils import Vector
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
for o in s.objects:
 if o.type=='MESH' and o.data.materials and o.data.materials[0].name.endswith('diffusion'):o.visible_camera=False
for m in bpy.data.materials:
 if 'lightguide' in m.name:
  p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Strength'].default_value=.55 if 'Turquoise' in m.name else .32;p.inputs['Roughness'].default_value=.2
 if 'gabbro' in m.name:
  nt=m.node_tree;tc=nt.nodes.new('ShaderNodeTexCoord')
  for n in nt.nodes:
   if n.type=='TEX_NOISE':nt.links.new(tc.outputs['Object'],n.inputs['Vector'])
  for n in nt.nodes:
   if n.type=='VALTORGB':n.color_ramp.elements[0].color=(.019,.022,.025,1);n.color_ramp.elements[1].color=(.025,.029,.032,1)
 if 'plaster' in m.name:
  p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.018,.023,.03,1)
s.render.resolution_x=1000;s.render.resolution_y=1200;s.render.resolution_percentage=100;s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=8;s.cycles.samples=128
bpy.ops.wm.save_as_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'))
s.render.filepath=str(B/'renders/hero-refined.png');bpy.ops.render.render(write_still=True)
