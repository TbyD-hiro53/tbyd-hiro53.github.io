import bpy,json
import numpy as np
from pathlib import Path
B=Path(__file__).resolve().parents[1];R=B/'repository';P='chrome-liturgy-v1'
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=6;s.cycles.samples=8;s.frame_set(1)
s.render.bake.margin=8;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8'
for name in ['T','DiscTop']:
 o=bpy.data.objects[name];bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 m=o.data.materials[0];nt=m.node_tree
 for kind in ['ROUGHNESS','NORMAL']:
  image=bpy.data.images.new(name+' '+kind,width=2048 if name=='DiscTop' else 1024,height=2048 if name=='DiscTop' else 1024,alpha=False)
  image.colorspace_settings.name='Non-Color';n=nt.nodes.new('ShaderNodeTexImage');n.image=image;nt.nodes.active=n
  bpy.ops.object.bake(type=kind)
  image.filepath_raw=str(R/f'{P}-{name.lower()}-{kind.lower()}.png');image.file_format='PNG';image.save();nt.nodes.remove(n)
  print('BAKED',name,kind,flush=True)
for o in s.objects:
 if o.name=='T' or o.name.startswith(('Ring','Disc')):o.hide_render=True
 if o.type=='MESH' and o.data.materials and o.data.materials[0].name.endswith('diffusion'):o.visible_camera=True
cam=s.camera;cam.location=(0,0,4.5);cam.rotation_euler=(np.pi/2,0,0);cam.data.type='PANO';cam.data.panorama_type='EQUIRECTANGULAR';cam.data.dof.use_dof=False
s.render.resolution_x=1024;s.render.resolution_y=512;s.render.resolution_percentage=100;s.cycles.samples=64
s.render.image_settings.file_format='OPEN_EXR';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='16';s.render.filepath=str(B/'renders/studio-linear.exr')
bpy.ops.render.render(write_still=True)
im=bpy.data.images.load(str(B/'renders/studio-linear.exr'));pix=np.array(im.pixels[:],dtype='<f2').reshape(512,1024,4)
(R/f'{P}-studio.f16').write_bytes(np.roll(pix,-256,axis=1).tobytes());print('HDR_ENV_READY',flush=True)
