"""Extrude the original alpha silhouette onto its original cylindrical shell."""
import json,math
from pathlib import Path
import numpy as np
from PIL import Image
B=Path(__file__).resolve().parents[1]
G=json.loads((B/'reference/geometry.json').read_text())
out={}
for k in range(4):
 im=Image.open(B/'reference'/f'neon{k}.png').convert('RGBA')
 rows=np.where((np.asarray(im)[:,:,3]>245).any(axis=1))[0]
 # Discard image-only vertical padding: actual lettering fills the original ring height.
 im=im.crop((0,max(0,int(rows[0])-10),im.width,min(im.height,int(rows[-1])+11))).resize((1536,384),Image.Resampling.LANCZOS)
 # Core only: the old texture contains a glow skirt that is not physical lettering.
 a=np.asarray(im)[:,:,3]>245
 h,w=a.shape
 # Reconstruct the original UV mapping, including original winding and seam.
 g=G[f'ringO{k}']; p=np.array(g['p']); uv=np.array(g['uv'])
 pairs=sorted([(u[0],math.atan2(v[0],v[2])) for u,v in zip(uv,p) if u[1]<.01])
 angle=np.unwrap([x[1] for x in pairs]); slope=(angle[-1]-angle[0])/(pairs[-1][0]-pairs[0][0]); offset=angle[0]-slope*pairs[0][0]
 r=float(np.linalg.norm(p[0,[0,2]])); height=float(np.ptp(p[:,1])); verts=[];faces=[];lookup={}
 def v(x,y,side):
  key=(x,y,side)
  if key not in lookup:
   an=offset+slope*x/w; radius=r-(.038 if side else 0)
   lookup[key]=len(verts);verts.append([radius*math.sin(an),-radius*math.cos(an),height*(.5-y/h)])
  return lookup[key]
 def quad(coords):faces.append([v(*p) for p in coords])
 for y in range(h):
  xs=np.where(a[y])[0]; j=0
  while j<len(xs):
   x0=int(xs[j]); x1=x0+1;j+=1
   while j<len(xs) and xs[j]==x1 and x1-x0<6:x1+=1;j+=1
   quad([(x0,y,0),(x1,y,0),(x1,y+1,0),(x0,y+1,0)])
   quad([(x0,y+1,1),(x1,y+1,1),(x1,y,1),(x0,y,1)])
  for x in xs:
   x=int(x)
   if y==0 or not a[y-1,x]:quad([(x,y,1),(x+1,y,1),(x+1,y,0),(x,y,0)])
   if y==h-1 or not a[y+1,x]:quad([(x,y+1,0),(x+1,y+1,0),(x+1,y+1,1),(x,y+1,1)])
   if x==0 or not a[y,x-1]:quad([(x,y,0),(x,y+1,0),(x,y+1,1),(x,y,1)])
   if x==w-1 or not a[y,x+1]:quad([(x+1,y,1),(x+1,y+1,1),(x+1,y+1,0),(x+1,y,0)])
 out[f'Glyph{k}']={'p':verts,'faces':faces}
 print(k,len(verts),len(faces),slope,offset,flush=True)
(B/'reference/glyphs.json').write_text(json.dumps(out,separators=(',',':')))
