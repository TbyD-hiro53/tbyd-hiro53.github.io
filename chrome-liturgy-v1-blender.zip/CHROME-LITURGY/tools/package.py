from pathlib import Path
from PIL import Image,ImageOps
import json,zipfile,hashlib,re,shutil
B=Path(__file__).resolve().parents[1];R=B/'repository';P='chrome-liturgy-v1'
im=Image.open(R/f'{P}-hero.jpg');assert im.size==(2400,2880),im.size
ImageOps.fit(im,(640,640),centering=(.5,.42)).save(R/'chrome-liturgy-thumb.jpg',quality=94)
readme=(B/'README-ja.md').read_text()
(R/f'{P}-README-ja.md').write_text(readme)
license_text='Three.js r128 — MIT License\nCopyright © 2010–2021 three.js authors\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n'
(R/f'{P}-LICENSE-libraries.txt').write_text(license_text)
with zipfile.ZipFile(R/f'{P}-blender.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 z.write(B/'scene/chrome-liturgy-master.blend','CHROME-LITURGY/scene/chrome-liturgy-master.blend')
 z.writestr('CHROME-LITURGY/README-ja.md',readme)
 z.write(R/'LICENSE.md','CHROME-LITURGY/LICENSE.md')
 for d in ['renders','repository']:z.writestr('CHROME-LITURGY/'+d+'/','')
 for f in (B/'tools').glob('*.py'):z.write(f,'CHROME-LITURGY/tools/'+f.name)
 for f in ['cyberwafer-v25.html','provenance.json']:z.write(B/'reference'/f,'CHROME-LITURGY/reference/'+f)
 for f in ['verification.json','native-verification.json','browser-verification.json']:z.write(B/'renders'/f,'CHROME-LITURGY/renders/'+f)
files=[p for p in R.glob('chrome-liturgy*') if p.is_file() and not p.name.endswith('-viewer.zip')]
launcher='''import http.server,webbrowser,os\nfrom pathlib import Path\nos.chdir(Path(__file__).resolve().parent)\nserver=http.server.ThreadingHTTPServer(("127.0.0.1",0),http.server.SimpleHTTPRequestHandler)\nurl="http://127.0.0.1:%d/chrome-liturgy.html"%server.server_port\nprint(url,flush=True)\nwebbrowser.open(url)\ntry:server.serve_forever()\nexcept KeyboardInterrupt:server.server_close()\n'''
command='''#!/bin/sh\ncd "$(dirname "$0")" || exit 1\nBUNDLED="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"\nif [ -x "$BUNDLED" ]; then exec "$BUNDLED" open-viewer.py; fi\nexec python3 open-viewer.py\n'''
with zipfile.ZipFile(R/f'{P}-viewer.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in files:
  if f.name=='chrome-liturgy.html':
   html=f.read_text().replace('href="index.html"','href="https://tbyd-hiro53.github.io/index.html"')
   html=re.sub(r'<a class="glass" href="chrome-liturgy-v1-viewer.zip" download>作品を保存</a>','',html)
   z.writestr(f.name,html)
  else:z.write(f,f.name)
 z.write(R/'apple-touch-icon.png','apple-touch-icon.png');z.write(R/'LICENSE.md','LICENSE.md')
 z.writestr('open-viewer.py',launcher)
 zi=zipfile.ZipInfo('open-viewer.command');zi.external_attr=(0o755<<16);z.writestr(zi,command)
 z.writestr('README-FIRST.txt','CHROME LITURGY（仮題）\nMac: open-viewer.command を実行。その他: Python 3 で open-viewer.py を実行。\n同じフォルダ内でローカルHTTPサーバーが起動し、ブラウザで作品が開きます。\nHTMLの直接オープンには対応しません。全ての描画用ファイルは同梱。\n作品一覧へのリンクは公開サイトへ移動します。保存ZIP自身への再保存ボタンは省略。\n「Blender原本」のZIPを解凍すると、編集可能な .blend と制作ソースを開けます。\n終了: 起動したターミナルで Control+C。\n')
qa=B/'archive-check';qa.mkdir(exist_ok=True)
with zipfile.ZipFile(R/f'{P}-viewer.zip') as z:assert z.testzip() is None;z.extractall(qa)
html=(qa/'chrome-liturgy.html').read_text()
for url in re.findall(r'(?:src|href)="([^"]+)"',html):
 if url.startswith(('https:','#')):continue
 assert (qa/url).is_file(),url
spec=json.loads((qa/f'{P}-scene.json').read_text())
for mesh in spec['meshes']:assert (qa/mesh['file']).stat().st_size==mesh['bytes']
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in R.glob('chrome-liturgy*') if p.is_file()}
(B/'renders/delivery-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'archive_check':'passed','files':len(manifest),'viewer_zip_bytes':(R/f'{P}-viewer.zip').stat().st_size,'native_zip_bytes':(R/f'{P}-blender.zip').stat().st_size},indent=2))
