import bpy
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
for f in range(1,866):
 s.frame_set(f)
 for i in range(6):
  o=bpy.data.objects[f'Disc{i}'];o.hide_render=o.scale.x<.0001 or (abs(o.location.z-3)<1e-7 and abs(o.scale.x-2.05)<1e-6);o.keyframe_insert('hide_render',frame=f)
for action in bpy.data.actions:
 for layer in action.layers:
  for strip in layer.strips:
   for slot in action.slots:
    bag=strip.channelbag(slot)
    if bag:
     for fc in bag.fcurves:
      if fc.data_path=='hide_render':
       for k in fc.keyframe_points:k.interpolation='CONSTANT'
s.frame_set(1);assert bpy.data.objects['Disc0'].hide_render
s.frame_set(2);assert not bpy.data.objects['Disc0'].hide_render
s.frame_set(73);bpy.ops.wm.save_as_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));print('COINCIDENT_SURFACE_VISIBILITY_FIXED',flush=True)
