import bpy,math,json
from pathlib import Path
from mathutils import Vector
B=Path(__file__).resolve().parents[1];R=B/'repository'
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
for k in range(4):
 o=bpy.data.objects[f'Ring{k}'];me=o.data;normals=[None]*len(me.loops)
 rr=[math.hypot(v.co.x,v.co.y) for v in me.vertices];outer=max(rr)
 for p in me.polygons:
  radii=[rr[me.loops[i].vertex_index] for i in p.loop_indices]
  radial=max(radii)-min(radii)<.00001
  for li in p.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co
   if radial:
    n=Vector((v.x,v.y,0)).normalized()
    if sum(radii)/len(radii)<outer-.01:n.negate()
    normals[li]=n
   else:normals[li]=p.normal.copy()
 me.normals_split_custom_set(normals)
s.frame_set(73)
s.render.resolution_x=2400;s.render.resolution_y=2880;s.render.resolution_percentage=100;s.cycles.samples=192;s.cycles.adaptive_threshold=.015;s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=8
s.camera.data.dof.aperture_fstop=13
s['title_status']='CHROME LITURGY (working title)'
s['physical_units']='Source scale preserved. Glyph radial thickness 0.038 source units; T edge radius 0.012; disc edge radius 0.003.'
s['browser_method']='Evaluated meshes and baked roughness/normal textures; Cycles HDR light probe; approximate realtime PBR reflections. Native photographs are Cycles path traced.'
# Store the original formula, including interactive pulse, as editable embedded documentation.
text=bpy.data.texts.new('SOURCE_MOTION.md');text.write('Cyberwafer v25 motion\nT: z = 0.18 sin(2 pi t / 8)\nRings: [-0.42, +0.60, -0.50, +0.36] rad/s\nSix discs: phase = (t - i * 2.4) mod 14.4\nSlot travel = 2.38 s; final 0.12 s shrink/reset/grow\nTap pulse: 1 + 0.05 * heartWave(pump / 0.78) * exp(-1.6 pump)\nInteractive pulse is evaluated in the browser; the native timeline stores the untouched idle cycle at 60 fps. Ring/T phases continue beyond the disc cycle; 14.4 s is not a seamless whole-scene loop.\n')
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'))
s.render.image_settings.file_format='OPEN_EXR';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='16'
s.render.filepath=str(B/'renders/hero-final.exr');bpy.ops.render.render(write_still=True)
s.render.image_settings.file_format='JPEG';s.render.image_settings.quality=96;s.render.image_settings.color_mode='RGB';bpy.data.images['Render Result'].save_render(str(R/'chrome-liturgy-v1-hero.jpg'),scene=s)
print('FINAL_HERO_READY',flush=True)
