from pathlib import Path
import re
B=Path(__file__).resolve().parents[1];R=B/'repository'
JA='Cyberwafer v25の構造と運動を、磨かれた金属と厚みのある光の文字で再構成。ピンクから赤へ移るT、青緑の文字環、循環するクローム円盤。ドラッグで回転、ピンチで拡大、タップで拍動。Blender原本と高精細写真を収録。'
EN='The structure and motion of Cyberwafer v25, recast in polished metal and solid luminous lettering. A pink-to-red T, turquoise text rings and circulating chrome wafers. Drag to orbit, pinch to zoom, tap to pulse. Includes the Blender master and a high-resolution photograph.'
entry=f'''<!-- CHROME_LITURGY_START -->
<article class="entry" data-k="gl">
  <a class="entry-main" href="chrome-liturgy.html">
    <div class="row"><span class="idx">ASSET 21</span><span class="name">CHROME LITURGY</span></div>
    <p class="desc" lang="ja">{JA}</p>
    <p class="desc" lang="en">{EN}</p>
    <div class="spec"><span class="chip live">Live</span><span class="chip">Blender</span><span class="chip">Physical materials</span></div>
    <span class="thumb"><img src="chrome-liturgy-thumb.jpg" alt="CHROME LITURGY — 薄膜の赤いTとクローム円盤" width="640" height="640" loading="lazy" decoding="async"></span>
  </a>
</article>
<!-- CHROME_LITURGY_END -->
'''
p=R/'index.html';s=p.read_text()
if '<!-- CHROME_LITURGY_START -->' in s:s=re.sub(r'<!-- CHROME_LITURGY_START -->.*?<!-- CHROME_LITURGY_END -->\n?',entry,s,flags=re.S)
else:
 start=s.index('href="cyberwafer.html"');end=s.index('</article>',start)+len('</article>');s=s[:end]+'\n'+entry+s[end:]
s=s.replace('>21 assets + 1 study<','>22 assets + 1 study<');p.write_text(s)
p=R/'CANON_TEXT.md';s=p.read_text();block=f'''## ASSET 21 — CHROME LITURGY

**制作上の仮題** 作者の命名確認後に変更可能。独立した作品としてCANONの直後、一覧2番目に配置。

**説明 JA**\n{JA}

**説明 EN**\n{EN}

**制作記録** Cyberwafer v25 の元形状、リング角速度、Tの浮遊、円盤のスロット循環、タップ時の0.78秒の拍動を継承。素材・照明・背景は本作独自。新しい世界設定・断章は追加していない。WebGLはBlenderの評価済み形状・ベイク画像・HDR照明を使用する近似PBR表示。高精細写真はCyclesによるパストレーシング。

---

'''
if '## ASSET 21 — CHROME LITURGY' not in s:s=s.replace('## ASSET 01 — Object',block+'## ASSET 01 — Object');p.write_text(s)
links=re.findall(r'<a class="entry-main" href="([^"]+)"', (R/'index.html').read_text());assert links[:2]==['cyberwafer.html','chrome-liturgy.html'],links[:3]
print('Registry positions verified:',links[:3])
