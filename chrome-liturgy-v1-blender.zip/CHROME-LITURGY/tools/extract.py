import re,json,base64,io,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
B=Path(__file__).resolve().parents[1]
s=(B/'reference/cyberwafer-v25.html').read_text()
geo=json.loads(re.search(r'var GEO = (.*);',s).group(1))
tex=json.loads(re.search(r'var TEX = (.*);',s).group(1))
out={}
for name,g in geo.items():
 p=np.frombuffer(base64.b64decode(g['p']),'<i2').reshape(-1,3)*g['ps']+g['po']
 n=np.frombuffer(base64.b64decode(g['n']),'i1').reshape(-1,3)/127
 uv=np.frombuffer(base64.b64decode(g['t']),'<u2').reshape(-1,2)/65535
 idx=np.frombuffer(base64.b64decode(g['i']),'<u2').reshape(-1,3)
 out[name]={'p':p.tolist(),'n':n.tolist(),'uv':uv.tolist(),'tri':idx.tolist()}
 print(name,len(p),p.min(0),p.max(0))
for name,data in tex.items():
 im=Image.open(io.BytesIO(base64.b64decode(data.split(',')[1])))
 im.save(B/'reference'/f'{name}.png')
 print(name,im.size)
(B/'reference/geometry.json').write_text(json.dumps(out,separators=(',',':')))
(B/'reference/provenance.json').write_text(json.dumps({'source':'https://github.com/TbyD-hiro53/tbyd-hiro53.github.io/blob/b4f574c/cyberwafer.html','sha256':hashlib.sha256(s.encode()).hexdigest()},indent=2))
