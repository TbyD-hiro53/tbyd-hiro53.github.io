"""Export evaluated native geometry, with split normals, for the r128 viewer."""
import bpy,json,struct
from pathlib import Path
import numpy as np
B=Path(__file__).resolve().parents[1];R=B/'repository';prefix='chrome-liturgy-v1'
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene;s.frame_set(1)
dg=bpy.context.evaluated_depsgraph_get();spec={'meshes':[],'source':'Cyberwafer v25','coordinates':'Three.js Y up','fps':60}
for name in ['T','Ring0','Ring1','Ring2','Ring3','DiscTop','GalleryFloor','GalleryWall']:
 o=bpy.data.objects[name];ev=o.evaluated_get(dg);m=ev.to_mesh();m.calc_loop_triangles();uv=m.uv_layers.active
 pos=[];norm=[];uvs=[];indices=[];lookup={}
 for tri in m.loop_triangles:
  for li in tri.loops:
   co=m.vertices[m.loops[li].vertex_index].co;n=m.corner_normals[li].vector
   vt=uv.data[li].uv if uv else (0,0)
   values=(co.x,co.z,-co.y,n.x,n.z,-n.y,float(vt[0]),float(vt[1]))
   key=tuple(round(v,6) for v in values)
   if key not in lookup:
    lookup[key]=len(pos);pos.append(values[:3]);norm.append(values[3:6]);uvs.append(values[6:])
   indices.append(lookup[key])
 data=np.concatenate([np.array(pos,dtype='<f4').ravel(),np.array(norm,dtype='<f4').ravel(),np.array(uvs,dtype='<f4').ravel()]).tobytes()+np.array(indices,dtype='<u4').tobytes()
 filename=f'{prefix}-{name.lower()}.bin';(R/filename).write_bytes(data)
 spec['meshes'].append({'name':name,'file':filename,'vertices':len(pos),'indices':len(indices),'position':[o.location.x,o.location.z,-o.location.y],'scale':list(o.scale),'bytes':len(data)})
 print(name,len(pos),len(indices)//3,len(data),flush=True);ev.to_mesh_clear()
(R/f'{prefix}-scene.json').write_text(json.dumps(spec,separators=(',',':')))
