import bpy,math,json
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
speed=[-.42,.6,-.5,.36];Y=[3,2.45,1.8,1,0,-1.05,-2.15];S=[2.05,1.6,1.22,.88,.56,.3,.02]
def pose(u):
 if u<14.28:
  i=min(5,int(u/2.38));f=(u-i*2.38)/2.38;return Y[i]+(Y[i+1]-Y[i])*f,S[i]+(S[i+1]-S[i])*f
 if u<14.32:return Y[6],S[6]*(1-(u-14.28)/.04)
 if u<14.36:return Y[6] if u<14.34 else Y[0],0
 return Y[0],S[0]*(u-14.36)/.04
errors=[]
for frame in [1,2,73,145,287,431,720,858,859,860,861,862,863,864,865]:
 s.frame_set(frame);t=(frame-1)/60
 errors.append(abs(bpy.data.objects['T'].location.z-.18*math.sin(2*math.pi*t/8)))
 for i,v in enumerate(speed):errors.append(abs(bpy.data.objects[f'Ring{i}'].rotation_euler.z-v*t))
 for i in range(6):
  z,sc=pose((t-i*2.4)%14.4);o=bpy.data.objects[f'Disc{i}'];errors.extend([abs(o.location.z-z),abs(o.scale.x-sc)])
assert max(errors)<1e-5,max(errors)
s.frame_set(1);assert bpy.data.objects['Disc0'].hide_render
s.frame_set(2);assert not bpy.data.objects['Disc0'].hide_render
for o in s.objects:
 if o.type=='MESH':assert all(math.isfinite(v) for vertex in o.data.vertices for v in vertex.co)
report={'passed':True,'sampled_frames':15,'max_motion_error':max(errors),'coincident_surface_visibility':'verified at cycle start and next frame','source_geometry':'T/disc decoded directly from v25; glyph cores extruded within original ring shells','native_fps':s.render.fps,'native_frame_range':[s.frame_start,s.frame_end],'glyph_radial_thickness':.038,'title':'CHROME LITURGY (working title)','browser_pulse':'verified separately against v25; interactive only','photograph_resolution':[s.render.resolution_x,s.render.resolution_y]}
(B/'renders/native-verification.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
