import bpy,sys
from pathlib import Path
B=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(B/'scene/chrome-liturgy-master.blend'));s=bpy.context.scene
s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=8;s.cycles.samples=64
s.render.resolution_percentage=75;s.render.filepath=str(B/'renders/hero-study.png')
bpy.ops.render.render(write_still=True)
